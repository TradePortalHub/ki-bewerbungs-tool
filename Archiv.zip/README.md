# KI BewerbungsTool

## Installation
1. `npm install`
2. `mkdir data public/uploads`
3. `npm run dev`

## Einstellungen
- Admin: http://localhost:3000/admin
- Trage OpenAI API Key ein und konfiguriere JSON-Quelle.

## Bewerbung
- Besuche: http://localhost:3000/apply/{jobId}
- Führe den Chat, stelle nur Fragen zur Stelle/Firma, lade Dateien hoch und sende ab.