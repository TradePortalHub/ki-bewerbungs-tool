// next.config.js
module.exports = {
  output: 'export',
}
